
/**
 * 
 */
/**
 * @author IWTRAINING
 *
 */
module LogicaDeProgramacao {
	
	requires java.desktop;
}

